'use client';

import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowDown } from 'lucide-react';

// Register ScrollTrigger plugin
if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

interface HeroCanvasProps {
  onLoaded: () => void;
}

export default function HeroCanvas({ onLoaded }: HeroCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);
  const [imagesLoaded, setImagesLoaded] = useState(false);
  const [progressText, setProgressText] = useState('0%');

  const frameCount = 40;

  // Generate frame path
  const getFrameUrl = (index: number) => {
    return `/sequence/frame_${index.toString().padStart(4, '0')}.jpg`;
  };

  useEffect(() => {
    let loadedCount = 0;
    const imagesArray: HTMLImageElement[] = [];

    const handleImageLoad = () => {
      loadedCount++;
      const percent = Math.round((loadedCount / frameCount) * 100);
      setProgressText(`${percent}%`);

      // Trigger loading complete when first 10 frames are loaded for quick display
      if (loadedCount === 10) {
        onLoaded();
      }

      if (loadedCount === frameCount) {
        setImagesLoaded(true);
      }
    };

    const handleImageError = () => {
      loadedCount++;
      if (loadedCount === frameCount) {
        setImagesLoaded(true);
      }
    };

    // Preload all 40 frames
    for (let i = 0; i < frameCount; i++) {
      const img = new Image();
      img.onload = handleImageLoad;
      img.onerror = handleImageError;
      img.src = getFrameUrl(i);
      imagesArray.push(img);
    }
    imagesRef.current = imagesArray;
  }, [onLoaded]);

  useEffect(() => {
    if (!imagesLoaded || !canvasRef.current || !containerRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      drawFrame(frameObj.frame);
    };

    const drawFrame = (index: number) => {
      const img = imagesRef.current[index];
      if (!img || !ctx) return;

      // Object fit: cover algorithm for 2D Canvas
      const imgRatio = img.width / img.height;
      const canvasRatio = canvas.width / canvas.height;
      let drawWidth = canvas.width;
      let drawHeight = canvas.height;
      let offsetX = 0;
      let offsetY = 0;

      if (imgRatio > canvasRatio) {
        drawWidth = canvas.height * imgRatio;
        offsetX = (canvas.width - drawWidth) / 2;
      } else {
        drawHeight = canvas.width / imgRatio;
        offsetY = (canvas.height - drawHeight) / 2;
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
    };

    // Frame object to tween
    const frameObj = { frame: 0 };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    // Check for prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let ctxGSAP = gsap.context(() => {
      if (prefersReducedMotion) {
        // Accessibility: instantly display last stage, disable scroll scrubs
        frameObj.frame = frameCount - 1;
        drawFrame(frameCount - 1);
        
        // Simple static fade of overlay
        gsap.to(overlayRef.current, {
          opacity: 0,
          scrollTrigger: {
            trigger: containerRef.current,
            start: 'top top',
            end: '+=1000',
            scrub: true,
          }
        });
        return;
      }

      // 1. Scrub Canvas Frames via GSAP
      gsap.to(frameObj, {
        frame: frameCount - 1,
        snap: 'frame',
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top top',
          end: 'bottom bottom',
          scrub: 0.1, // brief smoothing
          onUpdate: (self) => {
            drawFrame(frameObj.frame);
          },
        },
      });

      // 2. Overlay Text Fade Out (Stage 1 ends around 15-25% scroll)
      gsap.to(overlayRef.current, {
        opacity: 0,
        y: -30,
        ease: 'power1.inOut',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top top',
          end: '+=20% top',
          scrub: true,
        },
      });

      // 3. Background Color Transition Beige (#F5E8D3) -> Coffee (#4A2C2A) during Stage 3 (40% - 60% scroll)
      gsap.to(containerRef.current, {
        backgroundColor: '#4A2C2A',
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: '35% top',
          end: '65% top',
          scrub: true,
        },
      });

      // 4. Canvas Fade Out (Stage 5, 80% to 100% scroll)
      gsap.to(canvasRef.current, {
        opacity: 0,
        scale: 0.98,
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: '80% top',
          end: '100% top',
          scrub: true,
        },
      });
    }, containerRef);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      ctxGSAP.revert();
    };
  }, [imagesLoaded]);

  // CTA Click handler to scroll to sections
  const scrollToMenu = () => {
    const el = document.getElementById('menu-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToLocation = () => {
    const el = document.getElementById('location-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[500vh] md:h-[500vh] bg-[#F5E8D3] transition-colors duration-500 overflow-hidden"
    >
      {/* Sticky Canvas Container */}
      <div className="sticky top-0 w-full h-screen overflow-hidden flex items-center justify-center">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full object-cover z-0"
          style={{ willChange: 'opacity, transform' }}
        />

        {/* Cinematic Gold Vignette Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20 pointer-events-none z-10" />

        {/* Sticky Overlay Content (Stage 1) */}
        <div
          ref={overlayRef}
          className="relative z-20 flex flex-col items-center justify-center text-center px-4 max-w-5xl h-full select-none"
        >
          {/* Logo Brand */}
          <h2 className="font-playfair text-[#FFF8F0] text-7xl md:text-9xl font-bold tracking-[0.2em] mb-4 animate-fade-in pr-[-0.2em]">
            COCOA
          </h2>

          {/* Subtitle */}
          <p className="font-cormorant italic text-[#C69C6D] text-2xl md:text-3xl tracking-widest mb-10 max-w-xl">
            Luxury Coffee & Artisan Desserts
          </p>

          {/* Pill CTAs */}
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 mt-4">
            <button
              onClick={scrollToMenu}
              className="px-8 py-3.5 border border-[#C69C6D] bg-transparent text-[#FFF8F0] font-poppins text-sm tracking-wider uppercase rounded-full hover:bg-[#C69C6D] hover:text-[#2B1810] active:scale-95 transition-all duration-300 w-52 sm:w-auto font-medium"
            >
              Explore Menu
            </button>
            <button
              onClick={() => {
                const el = document.getElementById('delivery-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-8 py-3.5 border border-[#C69C6D] bg-[#C69C6D] text-[#2B1810] font-poppins text-sm tracking-wider uppercase rounded-full hover:bg-transparent hover:text-[#FFF8F0] active:scale-95 transition-all duration-300 w-52 sm:w-auto font-medium"
            >
              Order Online
            </button>
            <button
              onClick={scrollToLocation}
              className="px-8 py-3.5 border border-[#C69C6D] bg-transparent text-[#FFF8F0] font-poppins text-sm tracking-wider uppercase rounded-full hover:bg-[#C69C6D] hover:text-[#2B1810] active:scale-95 transition-all duration-300 w-52 sm:w-auto font-medium"
            >
              Book A Table
            </button>
          </div>

          {/* Bouncing Chevron Indicator */}
          <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-2 text-[#FFF8F0]/80">
            <span className="font-poppins text-[10px] uppercase tracking-[0.3em] font-light">Scroll to Brew</span>
            <ArrowDown className="w-5 h-5 animate-bounce text-[#C69C6D]" />
          </div>
        </div>
      </div>
    </div>
  );
}
